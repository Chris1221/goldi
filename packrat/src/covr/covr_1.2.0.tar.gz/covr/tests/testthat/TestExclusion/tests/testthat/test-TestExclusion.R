test_that("test_me works", {
  expect_equal(test_me(2, 2), 4)
  expect_equal(test_exclusion(1), 2)
})
