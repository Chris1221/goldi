library(testthat)

test_check("TestS4")
